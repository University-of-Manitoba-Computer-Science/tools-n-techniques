#include <stdio.h>
#include <stdlib.h>
#include <fcntl.h>
#include <string.h>
#include <unistd.h>
#include <stdint.h>
#include <errno.h>

#define MESSAGE_SIZE 6

uint8_t message[MESSAGE_SIZE] = { 0x48, 0x45, 0x4c, 0x4c, 0x4f, 0x0a };

int main(void)
{
    ssize_t written;
    int mess = open("mess.c", O_WRONLY | O_APPEND);

    if ( mess > 0 )
    {
        for ( int i = 0; i < MESSAGE_SIZE; i++ )
        {
            written = write( mess, &message[i], 1 );
            if ( written < 0 )
            {
                perror( strerror( errno ) );
            }
        }
        close( mess );
    }
    else
    {
        perror( strerror( mess ) );
    }

    return EXIT_SUCCESS;
}
