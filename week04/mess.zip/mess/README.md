Mess
====

This folder is a mess.

Other than this README file, this folder contains:

* A `Makefile` that you *can* use to compile `mess.c`.
* A C program called `mess.c` that does *something*.

You should add and commit these files to your repository **before** you compile
and run them.

Compiling
---------

You have two options to compile the program `mess.c` (you only need to do one):

1. Run the compiler yourself (as in the readings):

   ```bash
   clang mess.c -o mess
   ```
2. Using the provided `Makefile`:

   ```bash
   make
   ```

We'll look at `Makefile`s and other tools for compiling projects later in the
course, so don't worry too much about what's in that file for now.

Running
-------

You can run this program on the command line. It takes no arguments and produces
no output, but it does have a side-effect.

```bash
./mess
```

Aside
-----

The `README.md` file that you're reading is a good example of a useful
`README.md` for a software project because it has a brief description of what
the project is (though it's vague in this case), a brief description of what the
other files in the folder are, and provides instructions for compiling and
running the code.
