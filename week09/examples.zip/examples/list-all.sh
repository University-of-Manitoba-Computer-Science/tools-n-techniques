#!/usr/bin/env bash

ls -alrth
