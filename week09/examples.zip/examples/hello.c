#include <stdio.h>
#include <stdlib.h> // for EXIT_SUCCESS

int main(void)
{
    char h;
#define MAX_LEN 100
    char message[MAX_LEN];

    printf("Hello, world!\n"); // standard output
    fprintf(stdout, "Hello, world!\n"); // standard output

    fgets(message, MAX_LEN, stdin); // standard input
    h = getchar(); // standard input

    fprintf(stderr, "Oh no! Errors!\n"); // standard error

    return EXIT_SUCCESS;
}
