import java.util.Scanner;

public class QuestionAsker 
{
    public static void main(String[] args)
    {
        final Scanner sc = new Scanner(System.in);
        String command;

        do
        {
            System.out.print("Is the answer yes or no? ");
            command = sc.next();
            System.out.printf("You answered [%s]\n", command);
        } while (!command.equals("q"));

    }
}
