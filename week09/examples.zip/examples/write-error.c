#include <stdio.h>
#include <stdlib.h>

int main(void)
{
    printf("This message is on STDOUT.\n");
    fprintf(stderr, "This message is on STDERR.\n");
    return EXIT_SUCCESS;
}
