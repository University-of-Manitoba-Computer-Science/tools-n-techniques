Robot
=====

This is a file with robots!

:robot:

:mechanical_arm:

:mechanical_leg:
