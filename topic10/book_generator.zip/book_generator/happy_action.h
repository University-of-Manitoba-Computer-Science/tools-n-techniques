#ifndef HAPPY_ACTION_H
#define HAPPY_ACTION_H

#include <string.h>
#include <stdlib.h>
#include <time.h>

char* get_happy_action(void);

#endif
