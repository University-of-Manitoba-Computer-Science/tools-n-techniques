#ifndef SAD_ACTION_H
#define SAD_ACTION_H

#include <string.h>
#include <stdlib.h>
#include <time.h>

char* get_sad_action(void);

#endif
