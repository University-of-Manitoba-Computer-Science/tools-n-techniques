#ifndef NEUTRAL_ACTION_C
#define NEUTRAL_ACTION_C

#include <string.h>
#include <stdlib.h>
#include <time.h>

char* get_neutral_action(void);

#endif
