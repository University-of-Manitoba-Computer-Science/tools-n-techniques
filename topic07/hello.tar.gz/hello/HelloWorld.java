import java.util.Scanner;

public class HelloWorld
{
    public static void main(String... args)
    {
        final Scanner sc = new Scanner(System.in);
        final int left, right, sum;

        System.out.println("Let's add x+y!");
        System.out.print("Enter the left side (x): ");
        left = sc.nextInt();

        System.out.print("Enter the right side (y): ");
        right = sc.nextInt();

        System.out.println("Thanks! Calculating...");
        sum = add(left, right);
        System.out.printf("The sum is: %d\n", sum);
        System.out.println("Thanks for letting me calculate for you!");
        sc.close();
    }

    public static int add(final int left, final int right)
    {
        final int sum;

        System.out.println("\tAbout to add left to right.");
        sum = left + right;
        System.out.println("\tHeading back to the caller.");

        return sum;
    }
}
